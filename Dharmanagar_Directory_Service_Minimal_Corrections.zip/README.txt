DHARMANAGAR DIRECTORY SERVICE — minimal corrections to the original preferred design

Preserved:
- Original large title and font sizes, colors, category layout, advertisements, rules, and footer.
- Birthday Greetings and Feedback & Suggestions remain in the top navigation.

Changed only:
- Top navigation and Emergency Service heading now say “জরুরি বার্তা”.
- Removed the duplicate lower Birthday Greetings section.
- Removed the duplicate lower Feedback & Suggestions section.
- Removed the unnecessary middle “পরিষেবার তালিকা” block.
- Increased the size/space of Emergency Service cards.

Google Sheets data connection and live search still need to be connected in a later step.
